﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReleaseSetup
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        private int index;
        private Dictionary<int, UserControl> userControls;

        public MainWindow()
        {
            userControls = new Dictionary<int, UserControl>()
            {
                {0, new Credentials() },
                {1, new BasicDetails() },
                {2, new DomainModel() },
                {3, new AtlasTrade() },
                {4, new AtlasDotNet() },
                {5, new AtlasWeb() },
                {6, new TeamCity() },
            };

            InitializeComponent();
        }

        private void ButtonFechar_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }


        private void ListViewMenu_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            index = ListViewMenu.SelectedIndex;
            SelectStep();
        }

        private void SelectStep()
        {
            if (Submit == null)
                return;

            MoveCursorMenu(index);
            GridPrincipal.Children.Clear();
            GridPrincipal.Children.Add(userControls[index]);

            if (index == 6)
            {
                Submit.Visibility = Visibility.Visible;
                NextBtn.Visibility = Visibility.Hidden;
            }
            else
            {
                Submit.Visibility = Visibility.Hidden;
                NextBtn.Visibility = Visibility.Visible;
            }
        }

        private void MoveCursorMenu(int index)
        {
            TrainsitionigContentSlide.OnApplyTemplate();
            GridCursor.Margin = new Thickness(0, (90 + (60 * index)), 0, 0);
        }

        private void PreviousBtn_OnClick(object sender, RoutedEventArgs e)
        {
            if (index > 0)
                index--;

            ListViewMenu.SelectedIndex = index;
        }

        private void NextBtn_OnClick(object sender, RoutedEventArgs e)
        {
            if (index < 6)
                index++;

            ListViewMenu.SelectedIndex = index;
        }

        private void MainWindow_OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void Submit_OnClick(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Are you sure?", "Start Release Setup", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                SetupProgress form = new SetupProgress();
                form.Show();
                this.Hide();
            }
        }
    }
}
